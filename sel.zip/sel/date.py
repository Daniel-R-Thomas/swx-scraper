import datetime
while (0 != 1):
    print raw_input(str(datetime.datetime.time(datetime.datetime.now()))[:-7]),
